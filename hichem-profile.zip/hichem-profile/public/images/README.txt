Put your real images here, then update the paths in src/data/config.js

Needed:
- profile.jpg          -> your circular profile picture (square photo, at least 400x400px)
- gallery-1.jpg ... gallery-8.jpg  -> your gallery photos (any aspect ratio works)
- og-cover.jpg          -> put this one directly in /public (not /public/images) — it's the
                           image shown when your link is shared on Instagram/iMessage/etc.
                           Recommended size: 1200x630px.

Until you add your own files, the site uses placeholder images loaded from the internet
so you can see the layout working immediately.
