Drop your ambient/background track here as: ambient.mp3

Then it will play (only when the person clicks the music button — never
autoplay) from src/components/MusicButton.jsx via the path "/audio/ambient.mp3".

Keep the file reasonably small (under ~3MB) since this site is optimized
for mobile visitors coming from an Instagram bio link.
