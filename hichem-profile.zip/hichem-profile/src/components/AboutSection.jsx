import { about } from '../data/config.js'

export default function AboutSection() {
  return (
    <section className="mt-20">
      <h2 className="font-display text-lg font-medium">About</h2>
      <p className="mt-4 text-[15px] leading-relaxed text-ink/80">
        {about.paragraph}
      </p>

      <div className="mt-5 flex flex-wrap gap-2">
        {about.interests.map((tag) => (
          <span
            key={tag}
            className="rounded-full border border-line bg-surface px-3.5 py-1.5 text-xs text-ink/80 transition-all duration-300 hover:-translate-y-0.5 hover:border-accent/40 hover:text-accent hover:shadow-glow"
          >
            {tag}
          </span>
        ))}
      </div>
    </section>
  )
}
