import { useEffect, useState } from 'react'
import { X, ChevronLeft, ChevronRight } from 'lucide-react'
import { gallery } from '../data/config.js'

const spanClass = {
  tall: 'row-span-2',
  wide: 'col-span-2',
  square: '',
}

export default function PhotoGallery() {
  const [activeIndex, setActiveIndex] = useState(null)
  const isOpen = activeIndex !== null

  useEffect(() => {
    if (!isOpen) return
    const onKey = (e) => {
      if (e.key === 'Escape') setActiveIndex(null)
      if (e.key === 'ArrowRight') setActiveIndex((i) => (i + 1) % gallery.length)
      if (e.key === 'ArrowLeft') setActiveIndex((i) => (i - 1 + gallery.length) % gallery.length)
    }
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [isOpen])

  return (
    <section className="mt-20">
      <h2 className="font-display text-lg font-medium">Moments</h2>

      <div className="mt-4 grid grid-cols-2 gap-2 [grid-auto-rows:110px]">
        {gallery.map((item, i) => (
          <button
            key={i}
            onClick={() => setActiveIndex(i)}
            className={`group relative overflow-hidden rounded-xl border border-line ${spanClass[item.span] || ''}`}
            aria-label="Open photo"
          >
            <img
              src={item.src}
              alt=""
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-black/0 transition-colors duration-300 group-hover:bg-black/10" />
          </button>
        ))}
      </div>

      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm animate-riseIn"
          onClick={() => setActiveIndex(null)}
        >
          <button
            onClick={() => setActiveIndex(null)}
            className="absolute right-5 top-5 rounded-full border border-line p-2 text-ink/80 hover:text-accent"
            aria-label="Close"
          >
            <X size={20} />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation()
              setActiveIndex((i) => (i - 1 + gallery.length) % gallery.length)
            }}
            className="absolute left-3 rounded-full p-2 text-ink/70 hover:text-accent sm:left-6"
            aria-label="Previous photo"
          >
            <ChevronLeft size={26} />
          </button>

          <img
            src={gallery[activeIndex].src}
            alt=""
            onClick={(e) => e.stopPropagation()}
            className="max-h-[80svh] max-w-[88vw] rounded-lg object-contain shadow-soft"
          />

          <button
            onClick={(e) => {
              e.stopPropagation()
              setActiveIndex((i) => (i + 1) % gallery.length)
            }}
            className="absolute right-3 rounded-full p-2 text-ink/70 hover:text-accent sm:right-6"
            aria-label="Next photo"
          >
            <ChevronRight size={26} />
          </button>
        </div>
      )}
    </section>
  )
}
