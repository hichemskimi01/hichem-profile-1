import { profile } from '../data/config.js'

export default function ProfileHero() {
  return (
    <section className="flex flex-col items-center text-center">
      <div
        className="relative animate-riseIn"
        style={{ animationDelay: '0ms' }}
      >
        {/* breathing glow ring behind the photo */}
        <div className="absolute inset-0 -z-10 rounded-full bg-accent/40 blur-2xl animate-breathe" />
        <div className="h-28 w-28 overflow-hidden rounded-full border border-line shadow-glow">
          <img
            src={profile.photo}
            alt={profile.name}
            className="h-full w-full object-cover"
          />
        </div>
      </div>

      <h1
        className="mt-5 animate-riseIn font-display text-2xl font-medium tracking-tight"
        style={{ animationDelay: '90ms' }}
      >
        {profile.name}
      </h1>

      <p
        className="mt-1 animate-riseIn text-sm text-muted"
        style={{ animationDelay: '150ms' }}
      >
        {profile.username}
      </p>

      <p
        className="mt-5 max-w-[26ch] animate-riseIn text-[15px] leading-relaxed text-ink/90"
        style={{ animationDelay: '210ms' }}
      >
        {profile.bio}
      </p>

      <p
        className="mt-4 animate-riseIn text-xs tracking-wide text-muted"
        style={{ animationDelay: '270ms' }}
      >
        {profile.tags.join('  •  ')}
      </p>

      <div
        className="mt-12 animate-riseIn opacity-60"
        style={{ animationDelay: '360ms' }}
        aria-hidden
      >
        <div className="mx-auto h-8 w-px animate-pulse bg-gradient-to-b from-transparent via-muted to-transparent" />
      </div>
    </section>
  )
}
