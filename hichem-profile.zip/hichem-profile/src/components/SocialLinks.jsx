import * as Icons from 'lucide-react'
import { socials } from '../data/config.js'

export default function SocialLinks() {
  return (
    <section className="mt-20">
      <h2 className="font-display text-lg font-medium">Find me elsewhere</h2>

      <div className="mt-4 flex flex-col gap-2">
        {socials.map((s) => {
          const Icon = Icons[s.icon] || Icons.Link
          return (
            <a
              key={s.platform}
              href={s.url}
              target="_blank"
              rel="noreferrer noopener"
              className="group flex items-center gap-3 rounded-xl border border-line bg-surface px-4 py-3.5 transition-all duration-300 hover:translate-x-1 hover:border-accent/40"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-surface2 text-ink/80 transition-colors duration-300 group-hover:text-accent">
                <Icon size={17} />
              </span>
              <span className="flex flex-1 flex-col leading-tight">
                <span className="text-sm text-ink">{s.platform}</span>
                <span className="text-xs text-muted">{s.handle}</span>
              </span>
              <span className="h-1.5 w-1.5 rounded-full bg-muted/40 transition-colors duration-300 group-hover:bg-accent" />
            </a>
          )
        })}
      </div>
    </section>
  )
}
