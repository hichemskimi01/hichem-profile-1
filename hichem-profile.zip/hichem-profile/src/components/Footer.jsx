import { site } from '../data/config.js'

export default function Footer() {
  return (
    <footer className="mt-24 flex flex-col items-center gap-1 text-center">
      <p className="text-xs text-muted">
        © {site.footerYear} {site.footerName}
      </p>
      <p className="text-xs text-muted/70">{site.footerLine}</p>
    </footer>
  )
}
