import { useRef, useState } from 'react'
import { Volume2, VolumeX } from 'lucide-react'
import { site } from '../data/config.js'

export default function MusicButton() {
  const audioRef = useRef(null)
  const [playing, setPlaying] = useState(false)

  const toggle = () => {
    const audio = audioRef.current
    if (!audio) return
    if (playing) {
      audio.pause()
    } else {
      // catches the case where /public/audio/ambient.mp3 hasn't been added yet
      audio.play().catch(() => {})
    }
    setPlaying(!playing)
  }

  return (
    <>
      {/* REPLACE: add your track at /public/audio/ambient.mp3 (see site.musicSrc in config.js) */}
      <audio ref={audioRef} src={site.musicSrc} loop preload="none" />
      <button
        onClick={toggle}
        aria-label={playing ? 'Pause ambient music' : 'Play ambient music'}
        aria-pressed={playing}
        className="glass fixed bottom-6 right-6 z-40 flex h-11 w-11 items-center justify-center rounded-full text-ink/80 shadow-soft transition-colors duration-300 hover:text-accent"
      >
        {playing ? <Volume2 size={18} /> : <VolumeX size={18} />}
      </button>
    </>
  )
}
