import ProfileHero from './components/ProfileHero.jsx'
import AboutSection from './components/AboutSection.jsx'
import PhotoGallery from './components/PhotoGallery.jsx'
import SocialLinks from './components/SocialLinks.jsx'
import Footer from './components/Footer.jsx'
import MusicButton from './components/MusicButton.jsx'

export default function App() {
  return (
    <div className="relative min-h-svh bg-bg text-ink overflow-x-hidden">
      {/* ambient light — the one orchestrated, always-on motion in the design */}
      <div
        aria-hidden
        className="pointer-events-none fixed -top-32 -left-24 h-72 w-72 rounded-full bg-accent/20 blur-[110px] animate-drift"
      />
      <div
        aria-hidden
        className="pointer-events-none fixed bottom-0 -right-24 h-80 w-80 rounded-full bg-accent/10 blur-[130px] animate-drift"
        style={{ animationDelay: '-9s' }}
      />
      <div className="grain" />

      <main className="relative z-10 mx-auto flex min-h-svh max-w-md flex-col px-6 pb-28 pt-14 sm:pt-20">
        <ProfileHero />
        <AboutSection />
        <PhotoGallery />
        <SocialLinks />
        <Footer />
      </main>

      <MusicButton />
    </div>
  )
}
